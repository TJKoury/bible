MACULA Hebrew Linguistic Datasets
https://github.com/Clear-Bible/macula-hebrew/
CC BY 4.0. See enclosed licenses for source-specific attributions.
Modified: converted to chapter JSON and lemma concordance shards.
Book IDs follow the Protestant 1–66 order. Original chapter/verse numbering is retained.
verse-map.json maps English-numbered references to original Hebrew references.
English glosses are contextual aids, not an exhaustive dictionary.
UBS semantic-domain fields have not been included.
